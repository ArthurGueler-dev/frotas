-- Fleet Management System - Database Schema
-- MySQL 8.0+
-- Execute this script in phpMyAdmin or via mysql CLI

USE f137049_in9aut;

-- ============================================
-- Table: areas
-- ============================================
CREATE TABLE IF NOT EXISTS areas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  geo_entity_id INT DEFAULT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_areas_geo_entity (geo_entity_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: vehicles
-- ============================================
CREATE TABLE IF NOT EXISTS vehicles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  plate VARCHAR(20) NOT NULL UNIQUE,
  brand VARCHAR(100) DEFAULT NULL,
  model VARCHAR(100) DEFAULT NULL,
  year INT DEFAULT NULL,
  area_id INT DEFAULT NULL,
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  INDEX idx_vehicles_plate (plate),
  INDEX idx_vehicles_active (is_active),
  INDEX idx_vehicles_area (area_id),

  FOREIGN KEY (area_id) REFERENCES areas(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: daily_mileage
-- ============================================
CREATE TABLE IF NOT EXISTS daily_mileage (
  id INT AUTO_INCREMENT PRIMARY KEY,
  vehicle_id INT NOT NULL,
  date DATE NOT NULL,
  km_driven DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
  start_odometer DECIMAL(10, 2) DEFAULT NULL,
  end_odometer DECIMAL(10, 2) DEFAULT NULL,
  calculation_method VARCHAR(50) NOT NULL DEFAULT 'mobile_api',
  data_source VARCHAR(50) DEFAULT NULL,
  record_count INT DEFAULT 0,
  calculation_status VARCHAR(20) DEFAULT 'pending',
  error_message TEXT DEFAULT NULL,
  retry_count INT DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  UNIQUE KEY uq_daily_mileage_vehicle_date (vehicle_id, date),
  INDEX idx_daily_mileage_date (date),
  INDEX idx_daily_mileage_status_date (calculation_status, date),
  INDEX idx_daily_mileage_vehicle (vehicle_id),

  FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Table: sync_logs
-- ============================================
CREATE TABLE IF NOT EXISTS sync_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  task_id VARCHAR(100) DEFAULT NULL,
  task_name VARCHAR(100) NOT NULL,
  started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  finished_at DATETIME DEFAULT NULL,
  status VARCHAR(20) DEFAULT 'running',
  vehicles_processed INT DEFAULT 0,
  vehicles_success INT DEFAULT 0,
  vehicles_failed INT DEFAULT 0,
  error_message TEXT DEFAULT NULL,

  INDEX idx_sync_logs_task_id (task_id),
  INDEX idx_sync_logs_started (started_at),
  INDEX idx_sync_logs_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Insert default area (Vitória - ES)
-- ============================================
INSERT IGNORE INTO areas (name, geo_entity_id)
VALUES ('Vitória - ES', NULL);

-- ============================================
-- Optional: Import existing vehicles
-- ============================================
-- If you have an existing FF_Veiculos table, you can import vehicles:
-- INSERT INTO vehicles (plate, brand, model, year, area_id, is_active)
-- SELECT
--   placa,
--   marca,
--   modelo,
--   ano,
--   1 as area_id,
--   1 as is_active
-- FROM FF_Veiculos
-- WHERE ativo = 1
-- ON DUPLICATE KEY UPDATE updated_at = NOW();

-- ============================================
-- Verify tables created
-- ============================================
SHOW TABLES LIKE '%area%';
SHOW TABLES LIKE '%vehicle%';
SHOW TABLES LIKE '%mileage%';
SHOW TABLES LIKE '%sync%';
